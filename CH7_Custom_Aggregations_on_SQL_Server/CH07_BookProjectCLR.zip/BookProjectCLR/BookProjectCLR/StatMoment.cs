using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.IO;
using Microsoft.SqlServer.Server;

[Serializable]
[Microsoft.SqlServer.Server.SqlUserDefinedAggregate(Format.UserDefined, MaxByteSize = -1, Name = "STAT_MOMENT", IsNullIfEmpty = true)]
public struct StatMoment: IBinarySerialize  //serialization must be developed on my own
{
    public void Init()
    {
        values = new List<double>();
    }

    //takes next value from a list of numbers to a list of values
    public void Accumulate(SqlDouble value, SqlInt32 n)
    {
        this.n = (double)n;

        if (value.IsNull)
            return;
        values.Add(value.Value);
    }

    //merges current instance of aggregation with previous instance
    public void Merge (StatMoment group)
    {
        this.values.AddRange(group.values);
        this.n = group.n;
    }

    //calculates n-th moment and returns result back to a client
    public SqlDouble Terminate ()
    {
        double valueCount = (double)values.Count;   //how many values are in the list
        double sum = 0;
        foreach (var item in values)                //sum of values in the list
        {
            sum += item;
        }

        double mean = sum / valueCount;             //mean of values in the list

        double poweredDiffsFromMean = 0;
        foreach (var item in values)                //the difference between each value and the mean
        {
            poweredDiffsFromMean += Math.Pow((item - mean), this.n);
        }

        return poweredDiffsFromMean / valueCount;   //statistical moment ready to go back to a client
    }

    //how to read data from serialized byte array
    public void Read(BinaryReader r)
    {
        using (MemoryStream stream = new MemoryStream((byte[])r.ReadBytes(Convert.ToInt32(r.BaseStream.Length))))
        {
            BinaryReader binaryReader = new BinaryReader(stream);
            binaryReader.BaseStream.Position = 0;

            int count = binaryReader.ReadInt32();

            if (count > -1)
            {
                this.values = new List<double>(count);
                for (int i = 0; i < count; i++)
                {
                    this.values.Add(binaryReader.ReadDouble());
                }
            }

            this.n = binaryReader.ReadDouble();
        }
    }

    //how to write data to serialized byte array
    public void Write(BinaryWriter w)
    {
        using (var stream = new MemoryStream())
        {
            var binaryWriter = new BinaryWriter(stream);
            binaryWriter.Write(this.values.Count);

            foreach (var tempDec in this.values)
            {
                binaryWriter.Write(tempDec);
            }
            binaryWriter.Write(this.n);
            w.Write(stream.ToArray());
        }
    }

    private List<double> values;    //list of values to be aggregated
    private double n;               //n-th power determining statistical moment
}
